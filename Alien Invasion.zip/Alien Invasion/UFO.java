import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class UFO here.
 * 
 * @author (Braden and Ashok) 
 * @version (a version number or a date)
 */
public class UFO extends Actor
{
    private int invade;
    GreenfootImage ufo = new GreenfootImage("ufo.png");

    private GreenfootSound ufoExp;
    public UFO()
    {
        invade = Greenfoot.getRandomNumber(1) + 1;
        ufoExp = new GreenfootSound("ufoExplosion.mp3");
    }

    public void act() 
    {
        setLocation(getX(), getY() + invade);
        turn (7);

        if (getY() == 749)
        {
            Space space = (Space)getWorld();
            space.removeObject(this);
        }

        else if(isTouching(Bullet.class))
        {
            Space space = (Space)getWorld();
            space.addScore(5);
            ufoExp.play();
            removeTouching(Bullet.class);
        }

    }
}
