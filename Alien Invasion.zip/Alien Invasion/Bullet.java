import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bullet here.
 * 
 * @author (Braden and Ashok) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
    public void act() 
    {

        setLocation(getX(),getY()-50); //distance between bullet

        if(isAtEdge())
        {
            getWorld().removeObject(this);
        }

        else if(isTouching(UFO.class))
        {
            removeTouching(UFO.class);
        }
        else if(isTouching(Life.class))
        {
          removeTouching(Life.class);  
        }

    }   

}
