import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rocket here.
 * 
 * @author (Braden and Ashok) 
 * @version (a version number or a date)
 */
public class Rocket extends Actor
{
    private static final int reload = 5;

    private int reloadCount;
    private GreenfootImage rocket = new GreenfootImage("rocket.png"); 
    private GreenfootImage boom = new GreenfootImage("boom.png");

    public Rocket()
    {
        reloadCount = 0;
    }

    public void act() 
    {
        reloadCount++;
        if (Greenfoot.isKeyDown("right"))
        {
            move(5);
        }
        if (Greenfoot.isKeyDown("left"))
        {
            move(-5);
        }
        if (Greenfoot.isKeyDown("Space"))
        {
            shotsFired();
        }
        if(isTouching(UFO.class))
        {
            Space space = (Space)getWorld();
            setImage(boom);
            Greenfoot.stop();
            space.gameOver();
            space.showText("YOU LOSE" , 265,425);

        }

    }  

    private void shotsFired() 
    {
        if (reloadCount >= reload) 
        {
            Bullet bullet = new Bullet();
            getWorld().addObject(bullet, getX(), getY());
            reloadCount = 1;
        }
    }
}
