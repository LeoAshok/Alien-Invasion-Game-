import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Life here.
 * 
 * @author (Braden and Ashok) 
 * @version (a version number or a date)
 */
public class Life extends Actor
{
    private int attack;
    public Life()
    {
        attack = Greenfoot.getRandomNumber(1) + 1;
    }

    public void act() 
    {
        setLocation(getX() , getY() + attack );
        turn(3);

        if (getY() == 749)
        {
            Space space = (Space)getWorld();
            space.removeObject(this);
            space.addScore(-2);            
        }
        else if(this.isTouching(Bullet.class))
        {
            Space space = (Space)getWorld();
            space.addScore(-3);
            removeTouching(Bullet.class);
        }
        else if(this.isTouching(Rocket.class))
        {
            Space space = (Space)getWorld();
            space.addScore(10);
            space.removeObject(this);
        }
    }    
}
