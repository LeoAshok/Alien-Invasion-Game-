import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Space here.
 * 
 * @author (Braden and Ashok) 
 * @version (a version number or a date)
 */
public class Space extends World
{
    private int score;

    public Space()
    {    
        super(530, 750, 1); 
        score = 0;
        displayScore();
        Rocket rocket = new Rocket();
        this.addObject(rocket, 265, 690);
    }

    public void act()
    {
        if(Greenfoot.getRandomNumber(200) < 1)
        {
            addObject(new Life(), Greenfoot.getRandomNumber(530), 10);
        }  

        if(Greenfoot.getRandomNumber(100) < 1)
        {
            addObject(new UFO(), Greenfoot.getRandomNumber(530), 10);
        }

    }

    public void addScore(int pts)
    {
        score = score + pts;
        displayScore();
        if( score <= 0)
        {
            Greenfoot.stop(); // You Lose  
            gameOver();
            showText("YOU LOSE" , 265,425);
        }
        else if (score > 250)
        {
            Greenfoot.stop(); // You Win
            gameOver();
            showText("YOU WIN" , 265,425);
        }
    }

    public void displayScore()
    {
        showText("Score:" + score, 265, 735);
    }

    public void renewScore()
    {
        displayScore();
    }

    public void gameOver()
    {
        showText("Game Over" , 265,375);
        showText("Your Final Score : " + score ,265,400);
    }

}
